import boto3
from botocore.exceptions import ClientError
from typing import List, Dict, Any, Optional
from ..base import DocumentSource, Document
from ..exceptions import SourceConnectionError, DocumentNotFoundError, InvalidConfigurationError


class S3Source(DocumentSource):
    def _get_client(self, config: Dict[str, Any]):
        """Crea y devuelve un cliente S3 con endpoint personalizado si se proporciona."""
        session = boto3.Session(
            aws_access_key_id=config.get('access_key'),
            aws_secret_access_key=config.get('secret_key'),
            region_name=config.get('region', 'eu-west-2')
        )
        endpoint_url = config.get('endpoint_url')
        if endpoint_url:
            return session.client('s3', endpoint_url=endpoint_url)
        return session.client('s3')

    def list_documents(self, config: Dict[str, Any]) -> List[Document]:
        bucket = config.get('bucket')
        prefix = config.get('prefix', '')
        if not bucket:
            raise InvalidConfigurationError("Missing 'bucket' in S3 config")

        s3 = self._get_client(config)
        try:
            paginator = s3.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket, Prefix=prefix)
            documents = []
            for page in pages:
                for obj in page.get('Contents', []):
                    documents.append(Document(
                        key=obj['Key'],
                        metadata={
                            'size': obj['Size'],
                            'last_modified': obj['LastModified'],
                            'etag': obj.get('ETag'),
                            'storage_class': obj.get('StorageClass'),
                        }
                    ))
            return documents
        except ClientError as e:
            raise SourceConnectionError(f"S3 error: {e}")

    def fetch_document(self, config: Dict[str, Any], key: str) -> Document:
        bucket = config.get('bucket')
        if not bucket:
            raise InvalidConfigurationError("Missing 'bucket' in S3 config")

        s3 = self._get_client(config)
        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            content = response['Body'].read()
            return Document(
                key=key,
                metadata={
                    'size': response['ContentLength'],
                    'last_modified': response['LastModified'],
                    'etag': response.get('ETag'),
                    'content_type': response.get('ContentType'),
                },
                content=content
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                raise DocumentNotFoundError(
                    f"Key '{key}' not found in bucket '{bucket}'")
            raise SourceConnectionError(f"S3 error: {e}")

    def fetch_documents(self, config: Dict[str, Any], keys: Optional[List[str]] = None) -> List[Document]:
        if keys:
            return [self.fetch_document(config, key) for key in keys]
        docs = self.list_documents(config)
        return [self.fetch_document(config, doc.key) for doc in docs]
