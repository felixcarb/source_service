from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class Document:
    """Document retrieved from a source."""
    key: str                     # Unique identifier (path, name, etc.)
    metadata: Dict[str, Any]     # Metadata (size, date, type, etc.)
    content: Optional[bytes] = None  # Document content


class DocumentSource(ABC):
    """Base interface for all document sources."""

    @abstractmethod
    def list_documents(self, config: Dict[str, Any]) -> List[Document]:
        """List available documents (metadata only)."""
        pass

    @abstractmethod
    def fetch_document(self, config: Dict[str, Any], key: str) -> Document:
        """Fetch a single document by its key."""
        pass

    @abstractmethod
    def fetch_documents(self, config: Dict[str, Any], keys: Optional[List[str]] = None) -> List[Document]:
        """Fetch one or more documents (all if keys is None)."""
        pass
